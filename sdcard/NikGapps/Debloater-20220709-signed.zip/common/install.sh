#!/sbin/sh
# Shell Script EDIFY Replacement

ProgressBarValues="
"


set_progress 1.00

exit_install

